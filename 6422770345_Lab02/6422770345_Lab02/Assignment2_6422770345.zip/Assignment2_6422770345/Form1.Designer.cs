﻿namespace Assignment2_6422770345
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            button3 = new Button();
            button2 = new Button();
            button4 = new Button();
            button1 = new Button();
            groupBox2 = new GroupBox();
            comboBox1 = new ComboBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            textBox1 = new TextBox();
            groupBox3 = new GroupBox();
            button5 = new Button();
            radioButton3 = new RadioButton();
            radioButton2 = new RadioButton();
            radioButton1 = new RadioButton();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label9 = new Label();
            groupBox4 = new GroupBox();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.BackColor = SystemColors.InactiveCaption;
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button4);
            groupBox1.Controls.Add(button1);
            groupBox1.Font = new Font("Arial", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(116, 305);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(332, 724);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Form Navigation";
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ControlDark;
            button3.Location = new Point(22, 192);
            button3.Name = "button3";
            button3.Size = new Size(288, 46);
            button3.TabIndex = 5;
            button3.Text = "User Group";
            button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ControlDark;
            button2.Location = new Point(22, 126);
            button2.Name = "button2";
            button2.Size = new Size(288, 46);
            button2.TabIndex = 4;
            button2.Text = "User Add-In";
            button2.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ControlDark;
            button4.Location = new Point(22, 259);
            button4.Name = "button4";
            button4.Size = new Size(288, 91);
            button4.TabIndex = 6;
            button4.Text = "User Group Add-In";
            button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ControlDark;
            button1.Location = new Point(22, 60);
            button1.Name = "button1";
            button1.Size = new Size(288, 46);
            button1.TabIndex = 3;
            button1.Text = "User Profile";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = SystemColors.InactiveCaption;
            groupBox2.Controls.Add(comboBox1);
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(textBox2);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(label2);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Font = new Font("Arial", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(464, 305);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(698, 350);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "User Information";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Mr.", "Mrs.", "Ms." });
            comboBox1.Location = new Point(226, 64);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(242, 52);
            comboBox1.TabIndex = 7;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(226, 257);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(414, 50);
            textBox3.TabIndex = 6;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(226, 192);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(414, 50);
            textBox2.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(58, 264);
            label4.Name = "label4";
            label4.Size = new Size(118, 44);
            label4.TabIndex = 4;
            label4.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(9, 198);
            label3.Name = "label3";
            label3.Size = new Size(208, 44);
            label3.TabIndex = 3;
            label3.Text = "Last Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(9, 132);
            label2.Name = "label2";
            label2.Size = new Size(211, 44);
            label2.TabIndex = 2;
            label2.Text = "First Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(58, 67);
            label1.Name = "label1";
            label1.Size = new Size(94, 44);
            label1.TabIndex = 1;
            label1.Text = "Title";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(226, 126);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(414, 50);
            textBox1.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = SystemColors.InactiveCaption;
            groupBox3.Controls.Add(button5);
            groupBox3.Controls.Add(radioButton3);
            groupBox3.Controls.Add(radioButton2);
            groupBox3.Controls.Add(radioButton1);
            groupBox3.Controls.Add(textBox6);
            groupBox3.Controls.Add(textBox5);
            groupBox3.Controls.Add(textBox4);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(label7);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(label5);
            groupBox3.Font = new Font("Arial", 13.875F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox3.Location = new Point(464, 661);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(698, 368);
            groupBox3.TabIndex = 2;
            groupBox3.TabStop = false;
            groupBox3.Text = "Account Information";
            // 
            // button5
            // 
            button5.BackColor = SystemColors.ControlDark;
            button5.Location = new Point(226, 319);
            button5.Name = "button5";
            button5.Size = new Size(288, 43);
            button5.TabIndex = 7;
            button5.Text = "Submit";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // radioButton3
            // 
            radioButton3.AutoSize = true;
            radioButton3.Location = new Point(456, 254);
            radioButton3.Name = "radioButton3";
            radioButton3.Size = new Size(189, 48);
            radioButton3.TabIndex = 12;
            radioButton3.TabStop = true;
            radioButton3.Text = "Student";
            radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(335, 254);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(97, 48);
            radioButton2.TabIndex = 11;
            radioButton2.TabStop = true;
            radioButton2.Text = "TA";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(226, 254);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(222, 48);
            radioButton1.TabIndex = 3;
            radioButton1.TabStop = true;
            radioButton1.Text = "Instructor";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(226, 193);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(414, 50);
            textBox6.TabIndex = 10;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(226, 135);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(414, 50);
            textBox5.TabIndex = 9;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(226, 72);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(414, 50);
            textBox4.TabIndex = 8;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(15, 196);
            label8.Name = "label8";
            label8.Size = new Size(161, 44);
            label8.TabIndex = 7;
            label8.Text = "Confirm";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(6, 254);
            label7.Name = "label7";
            label7.Size = new Size(224, 44);
            label7.TabIndex = 6;
            label7.Text = "User Group";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(9, 135);
            label6.Name = "label6";
            label6.Size = new Size(196, 44);
            label6.TabIndex = 5;
            label6.Text = "Password";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(9, 78);
            label5.Name = "label5";
            label5.Size = new Size(200, 44);
            label5.TabIndex = 4;
            label5.Text = "Username";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial", 19.875F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(6, 66);
            label9.Name = "label9";
            label9.Size = new Size(714, 62);
            label9.TabIndex = 3;
            label9.Text = "CSS326 Laboratory System";
            // 
            // groupBox4
            // 
            groupBox4.BackColor = SystemColors.ActiveCaption;
            groupBox4.Controls.Add(label9);
            groupBox4.Location = new Point(116, 114);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(1046, 185);
            groupBox4.TabIndex = 4;
            groupBox4.TabStop = false;
            groupBox4.Enter += groupBox4_Enter_1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(2216, 1397);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Controls.Add(groupBox4);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private Button button3;
        private Button button2;
        private Button button4;
        private Button button1;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox1;
        private Label label4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label5;
        private ComboBox comboBox1;
        private Button button5;
        private RadioButton radioButton3;
        private RadioButton radioButton2;
        private RadioButton radioButton1;
        private Label label9;
        private GroupBox groupBox4;
    }
}