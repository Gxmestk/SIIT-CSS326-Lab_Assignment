<html>
  <head>
    <title>Login Handler</title>
  </head>
  <body>
    <?php
      $username_from_html_form = $_POST["username"];
      $password_from_html_form = $_POST["password"];

      if ($username_from_html_form == "css326" && $password_from_html_form == "password!"){
        echo "Welcome!";
      } else {
        echo "Incorrect username or password!";
      }
    ?>
  </body>
</html>

