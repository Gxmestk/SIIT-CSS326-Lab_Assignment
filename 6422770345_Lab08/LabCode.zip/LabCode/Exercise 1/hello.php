<!DOCTYPE html>
<html>

<head>
    <title>Basic PHP</title>
</head>

<body>
    <?php
    echo "<h1>Hello, World</h1>";
    echo "10 + 20 = ";
    echo 10 + 20;
    echo "\n";
    ?>
</body>

</html>