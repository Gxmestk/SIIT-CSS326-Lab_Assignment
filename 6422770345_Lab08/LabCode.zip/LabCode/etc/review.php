<?php
$x = 75;
$y = 25;
 
function addition() {
  $GLOBALS['z'] = $GLOBALS['x'] + $GLOBALS['y'];
  
  echo $x;  // Cannot access $x 
}
 
addition();
echo $z;
