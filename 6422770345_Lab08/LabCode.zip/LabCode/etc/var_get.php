<?php
  echo "Learning " . $_GET["z1"]. " - ". $_GET["z2"] . " is easy";
?>

