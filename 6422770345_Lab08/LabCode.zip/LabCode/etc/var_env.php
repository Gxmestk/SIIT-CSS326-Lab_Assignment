<?php
  print_r($_ENV);
  echo $_ENV["USER"];
?>